// Finance Sentry — Pillar Pages: Cashflow Forecast & Net Worth
const { useState, useEffect, useMemo } = React;

// ─────────────────────────────────────────────────────────────────────────────
// Forecast engine — projects daily balance N days into the future
// ─────────────────────────────────────────────────────────────────────────────
function buildForecast(accounts, recurring, days, variablePerDay = FORECAST_DAILY_VARIABLE) {
  const liquid = accounts.filter(a => a.category === 'banking');
  const startBalance = liquid.reduce((s, a) => s + a.balanceUsd, 0);

  // Anchor "today" at the most recent date in our mock data so the forecast
  // looks lively (Apr 27 2026). In a real app, this would be `new Date()`.
  const today = new Date(2026, 3, 27);
  today.setHours(0, 0, 0, 0);

  // Expand recurring rules into concrete dated events within the window
  const events = [];
  recurring.forEach(rec => {
    const start = new Date(rec.nextDate);
    let cursor = new Date(start);
    const endDate = new Date(today);
    endDate.setDate(endDate.getDate() + days);
    while (cursor <= endDate) {
      if (cursor >= today) {
        events.push({
          date: new Date(cursor),
          name: rec.name,
          category: rec.category,
          type: rec.type,
          amount: rec.type === 'income' ? rec.amount : -rec.amount,
          confidence: rec.confidence,
          recurringId: rec.id,
        });
      }
      const next = new Date(cursor);
      if (rec.cadence === 'biweekly') next.setDate(next.getDate() + 14);
      else if (rec.cadence === 'weekly') next.setDate(next.getDate() + 7);
      else next.setMonth(next.getMonth() + 1); // monthly
      cursor = next;
    }
  });
  events.sort((a, b) => a.date - b.date);

  // Walk day-by-day and accumulate balance
  const series = [];
  let balance = startBalance;
  for (let d = 0; d <= days; d++) {
    const date = new Date(today);
    date.setDate(date.getDate() + d);

    if (d > 0) balance -= variablePerDay; // baseline variable burn

    const dayEvents = events.filter(e =>
      e.date.getFullYear() === date.getFullYear() &&
      e.date.getMonth() === date.getMonth() &&
      e.date.getDate() === date.getDate()
    );
    let dayInflow = 0, dayOutflow = 0;
    dayEvents.forEach(e => {
      balance += e.amount;
      if (e.amount >= 0) dayInflow += e.amount;
      else dayOutflow += -e.amount;
    });

    series.push({ date, day: d, balance, events: dayEvents, dayInflow, dayOutflow });
  }

  return { series, events, startBalance };
}

// ─────────────────────────────────────────────────────────────────────────────
// Cashflow Forecast Page
// ─────────────────────────────────────────────────────────────────────────────
function CashflowForecastPage({ accounts }) {
  const [loading, setLoading] = useState(true);
  const [horizon, setHorizon] = useState(60); // 30 | 60 | 90
  const [hover, setHover] = useState(null);
  const [lowBalanceThreshold, setLowBalanceThreshold] = useState(500);
  const [filterType, setFilterType] = useState('all'); // all | income | expense

  useEffect(() => { const t=setTimeout(()=>setLoading(false),700); return ()=>clearTimeout(t); }, []);

  const forecast = useMemo(
    () => buildForecast(accounts, RECURRING, horizon),
    [accounts, horizon]
  );

  const { series, events, startBalance } = forecast;
  const endBalance   = series[series.length - 1]?.balance ?? startBalance;
  const lowestPoint  = series.reduce((min, s) => s.balance < min.balance ? s : min, series[0]);
  const totalInflow  = series.reduce((s, d) => s + d.dayInflow, 0);
  const totalOutflow = series.reduce((s, d) => s + d.dayOutflow, 0);
  const netChange    = endBalance - startBalance;
  const lowDays      = series.filter(s => s.balance < lowBalanceThreshold).length;

  const visibleEvents = events.filter(e =>
    filterType === 'all' || (filterType === 'income' && e.amount > 0) || (filterType === 'expense' && e.amount < 0)
  );

  // ── Forecast chart geometry ────────────────────────────────────────────────
  const W = 880, H = 240, PL = 64, PR = 20, PT = 18, PB = 36;
  const iW = W - PL - PR, iH = H - PT - PB;
  const allBalances = series.map(s => s.balance);
  const minVal = Math.min(...allBalances, lowBalanceThreshold) * 0.92;
  const maxVal = Math.max(...allBalances) * 1.08;
  const range_ = maxVal - minVal || 1;
  const xStep = iW / (series.length - 1);
  const yScale = v => PT + iH - ((v - minVal) / range_) * iH;

  const linePath = series.map((s, i) =>
    `${i === 0 ? 'M' : 'L'}${PL + i * xStep},${yScale(s.balance)}`
  ).join(' ');
  const areaPath = `${linePath} L${PL + (series.length - 1) * xStep},${PT + iH} L${PL},${PT + iH} Z`;
  const thresholdY = yScale(lowBalanceThreshold);

  const fmtShortDate = d => d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  const fmtFullDate  = d => d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
  // X tick stride: ~10 ticks total
  const tickStride = Math.max(1, Math.round(series.length / 10));

  return (
    <div style={{ padding:24 }}>
      <div style={{ maxWidth:1200, margin:'0 auto', display:'flex', flexDirection:'column', gap:20 }}>

        {/* Page header */}
        <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap:16 }}>
          <div>
            <h1 style={{ fontSize:'22px', fontWeight:700, color:'var(--text-primary)' }}>Cashflow Forecast</h1>
            <p style={{ fontSize:'13px', color:'var(--text-secondary)', marginTop:4, maxWidth:560, lineHeight:1.5 }}>
              Projected balance from your liquid accounts based on detected recurring income, scheduled bills, and average daily variable spend.
            </p>
          </div>
          <div style={{ display:'flex', gap:4 }}>
            {[30, 60, 90].map(d => (
              <button key={d} onClick={() => setHorizon(d)}
                style={{ padding:'6px 14px', borderRadius:6, fontSize:'12px', fontWeight:500,
                  border:'1.5px solid', cursor:'pointer', fontFamily:'inherit', transition:'all 120ms',
                  borderColor: horizon===d ? 'var(--accent-default)' : 'var(--border-default)',
                  background:  horizon===d ? 'var(--accent-subtle)'  : 'var(--surface-card)',
                  color:       horizon===d ? 'var(--accent-default)' : 'var(--text-secondary)' }}>
                {d}d
              </button>
            ))}
          </div>
        </div>

        {/* KPI strip */}
        <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:16 }}>
          <StatCard label="Today's Liquid" value={loading?'—':fmt(startBalance)}
            icon="Wallet" loading={loading} />
          <StatCard label={`Projected (${horizon}d)`} value={loading?'—':fmt(endBalance)}
            icon="Activity" loading={loading}
            delta={netChange} deltaLabel={`${netChange>=0?'+':''}${fmt(netChange)}`} />
          <StatCard label="Lowest Point"
            value={loading?'—':fmt(lowestPoint?.balance ?? 0)}
            icon="TrendingDown" loading={loading}
            delta={lowestPoint && lowestPoint.balance < lowBalanceThreshold ? -1 : 1}
            deltaLabel={loading?'':lowestPoint?fmtShortDate(lowestPoint.date):''} />
          <StatCard label="Days Below Threshold" value={loading?'—':String(lowDays)}
            icon="AlertTriangle" loading={loading}
            delta={lowDays === 0 ? 1 : -1}
            deltaLabel={loading?'':`< ${fmt(lowBalanceThreshold)}`} />
        </div>

        {/* Risk banner */}
        {!loading && lowestPoint && lowestPoint.balance < lowBalanceThreshold && (
          <Alert variant="warning">
            <strong>Heads up:</strong> Balance is projected to dip to{' '}
            <strong>{fmt(lowestPoint.balance)}</strong> on{' '}
            <strong>{fmtFullDate(lowestPoint.date)}</strong>{' '}— below your{' '}
            <strong>{fmt(lowBalanceThreshold)}</strong> low-balance threshold.
            Consider moving funds from savings or delaying a discretionary expense.
          </Alert>
        )}

        {/* Forecast chart */}
        {loading ? <Skeleton height={300} radius={8} /> : (
        <Card style={{ padding:0 }}>
          <div style={{ padding:'18px 22px 0', display:'flex',
            alignItems:'flex-start', justifyContent:'space-between', gap:16, flexWrap:'wrap' }}>
            <div>
              <span style={{ fontSize:'11px', fontWeight:600, letterSpacing:'0.06em',
                textTransform:'uppercase', color:'var(--text-secondary)' }}>Projected Daily Balance</span>
              <div style={{ marginTop:4, fontSize:'13px', color:'var(--text-secondary)' }}>
                Hover the chart to inspect any day. Dots mark scheduled events.
              </div>
            </div>
            <div style={{ display:'flex', alignItems:'center', gap:10, fontSize:'12px',
              color:'var(--text-secondary)' }}>
              <Icon name="AlertTriangle" size="xs" style={{ color:'var(--status-warning)' }} />
              <span>Low-balance threshold</span>
              <input type="number" value={lowBalanceThreshold} step={50} min={0}
                onChange={e => setLowBalanceThreshold(Math.max(0, +e.target.value))}
                style={{ width:90, padding:'4px 8px', borderRadius:6,
                  border:'1px solid var(--border-default)', background:'var(--surface-bg)',
                  color:'var(--text-primary)', fontSize:'12px', outline:'none',
                  fontFamily:'JetBrains Mono,monospace' }} />
            </div>
          </div>

          <svg viewBox={`0 0 ${W} ${H}`} style={{ width:'100%', display:'block', marginTop:8 }}
            onMouseLeave={() => setHover(null)}>
            <defs>
              <linearGradient id="forecastFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="var(--accent-default)" stopOpacity="0.22" />
                <stop offset="100%" stopColor="var(--accent-default)" stopOpacity="0" />
              </linearGradient>
            </defs>

            {/* Y grid */}
            {[0, 0.25, 0.5, 0.75, 1].map(f => {
              const val = minVal + range_ * f;
              const y = yScale(val);
              return (
                <g key={f}>
                  <line x1={PL} y1={y} x2={W-PR} y2={y}
                    stroke="var(--border-default)" strokeWidth="0.5" strokeDasharray="3 3" />
                  <text x={PL-8} y={y+4} textAnchor="end" fill="var(--text-disabled)" fontSize="9">
                    ${Math.round(val/1000)}k
                  </text>
                </g>
              );
            })}

            {/* Threshold line */}
            {thresholdY > PT && thresholdY < PT+iH && (
              <g>
                <line x1={PL} y1={thresholdY} x2={W-PR} y2={thresholdY}
                  stroke="var(--status-warning)" strokeWidth="1" strokeDasharray="4 3" opacity="0.7" />
                <text x={W-PR-4} y={thresholdY-4} textAnchor="end"
                  fill="var(--status-warning)" fontSize="9" fontWeight="600">
                  threshold {fmt(lowBalanceThreshold)}
                </text>
              </g>
            )}

            {/* Filled area + line */}
            <path d={areaPath} fill="url(#forecastFill)" />
            <path d={linePath} fill="none" stroke="var(--accent-default)" strokeWidth="2"
              strokeLinejoin="round" />

            {/* Event dots */}
            {series.map((s, i) => {
              if (s.events.length === 0) return null;
              const x = PL + i * xStep, y = yScale(s.balance);
              const hasIncome  = s.events.some(e => e.amount > 0);
              const hasExpense = s.events.some(e => e.amount < 0);
              const color = hasIncome && !hasExpense ? 'var(--status-success)'
                : hasExpense && !hasIncome ? 'var(--status-error)'
                : 'var(--accent-default)';
              return (
                <circle key={i} cx={x} cy={y} r="3" fill={color}
                  stroke="var(--surface-card)" strokeWidth="1.5" />
              );
            })}

            {/* Lowest-point marker */}
            {lowestPoint && (() => {
              const i = lowestPoint.day;
              const x = PL + i * xStep, y = yScale(lowestPoint.balance);
              const isRisky = lowestPoint.balance < lowBalanceThreshold;
              return (
                <g>
                  <circle cx={x} cy={y} r="6" fill="none"
                    stroke={isRisky ? 'var(--status-warning)' : 'var(--status-success)'}
                    strokeWidth="2" />
                  <circle cx={x} cy={y} r="2.5"
                    fill={isRisky ? 'var(--status-warning)' : 'var(--status-success)'} />
                </g>
              );
            })()}

            {/* X labels */}
            {series.map((s, i) => i % tickStride !== 0 ? null : (
              <text key={i} x={PL + i * xStep} y={H-8} textAnchor="middle"
                fill="var(--text-disabled)" fontSize="9">{fmtShortDate(s.date)}</text>
            ))}

            {/* Hover targets */}
            {series.map((s, i) => (
              <rect key={i} x={PL + i * xStep - xStep / 2} y={PT}
                width={xStep} height={iH} fill="transparent"
                onMouseEnter={() => setHover(i)} style={{ cursor:'crosshair' }} />
            ))}

            {/* Hover dot + tooltip */}
            {hover != null && (() => {
              const s = series[hover];
              const x = PL + hover * xStep, y = yScale(s.balance);
              const tw = 200;
              const evCount = s.events.length;
              const th = 56 + evCount * 14;
              const tx = x > W - tw - 20 ? x - tw - 12 : x + 12;
              const ty = y > PT + iH/2 ? y - th - 8 : y + 8;
              return (
                <g>
                  <line x1={x} y1={PT} x2={x} y2={PT+iH}
                    stroke="var(--border-default)" strokeWidth="1" strokeDasharray="3 3" />
                  <circle cx={x} cy={y} r="5" fill="var(--accent-default)"
                    stroke="var(--surface-card)" strokeWidth="2" />
                  <rect x={tx} y={ty} width={tw} height={th} rx="6"
                    fill="var(--surface-card)" stroke="var(--border-default)" strokeWidth="1" />
                  <text x={tx+10} y={ty+15} fill="var(--text-secondary)"
                    fontSize="10" fontWeight="600">{fmtFullDate(s.date)}</text>
                  <text x={tx+10} y={ty+34} fill="var(--text-primary)"
                    fontSize="13" fontWeight="700">{fmt(s.balance)}</text>
                  <text x={tx+tw-10} y={ty+34} textAnchor="end"
                    fill="var(--text-disabled)" fontSize="9">balance</text>
                  {s.events.map((e, ei) => (
                    <g key={ei}>
                      <circle cx={tx+14} cy={ty+50+ei*14} r="2.5"
                        fill={e.amount > 0 ? 'var(--status-success)' : 'var(--status-error)'} />
                      <text x={tx+22} y={ty+53+ei*14} fill="var(--text-secondary)" fontSize="10">
                        {e.name.length > 18 ? e.name.slice(0,17)+'…' : e.name}
                      </text>
                      <text x={tx+tw-10} y={ty+53+ei*14} textAnchor="end"
                        fill={e.amount > 0 ? 'var(--status-success)' : 'var(--text-primary)'}
                        fontSize="10" fontWeight="600" fontFamily="JetBrains Mono,monospace">
                        {e.amount > 0 ? '+' : '-'}{fmt(Math.abs(e.amount))}
                      </text>
                    </g>
                  ))}
                </g>
              );
            })()}
          </svg>

          {/* Legend */}
          <div style={{ display:'flex', gap:18, padding:'10px 22px 18px',
            borderTop:'1px solid var(--border-default)', marginTop:6, flexWrap:'wrap' }}>
            {[
              ['Projected balance', 'var(--accent-default)', 'line'],
              ['Income event',      'var(--status-success)', 'dot'],
              ['Expense event',     'var(--status-error)',   'dot'],
              ['Threshold',         'var(--status-warning)', 'dash'],
            ].map(([label, color, kind]) => (
              <div key={label} style={{ display:'flex', alignItems:'center', gap:6 }}>
                {kind === 'line' && <div style={{ width:18, height:2, background:color, borderRadius:1 }} />}
                {kind === 'dot'  && <div style={{ width:8, height:8, borderRadius:'50%', background:color }} />}
                {kind === 'dash' && <div style={{ width:18, height:1.5, background:color, borderTop:`1.5px dashed ${color}`, opacity:0.7 }} />}
                <span style={{ fontSize:'11px', color:'var(--text-secondary)' }}>{label}</span>
              </div>
            ))}
          </div>
        </Card>
        )}

        {/* Two-column: summary + recurring breakdown */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
          {/* Summary card */}
          <Card>
            <div style={{ fontSize:'11px', fontWeight:600, letterSpacing:'0.06em',
              textTransform:'uppercase', color:'var(--text-secondary)', marginBottom:12 }}>
              {horizon}-day Summary
            </div>
            {[
              ['Recurring inflow',  totalInflow,  'var(--status-success)', 'ArrowUpRight'],
              ['Recurring outflow', totalOutflow, 'var(--status-error)',   'ArrowDownRight'],
              ['Variable spend (est.)', FORECAST_DAILY_VARIABLE * horizon, 'var(--text-secondary)', 'Activity'],
              ['Net change',        netChange, netChange>=0?'var(--status-success)':'var(--status-error)', netChange>=0?'TrendingUp':'TrendingDown'],
            ].map(([label, value, color, icon], i, arr) => (
              <div key={label} style={{ display:'flex', alignItems:'center', justifyContent:'space-between',
                padding:'12px 0', borderBottom: i < arr.length - 1 ? '1px solid var(--border-default)' : undefined }}>
                <div style={{ display:'flex', alignItems:'center', gap:10 }}>
                  <Icon name={icon} size="sm" style={{ color }} />
                  <span style={{ fontSize:'13px', color:'var(--text-secondary)' }}>{label}</span>
                </div>
                <span style={{ fontFamily:'JetBrains Mono,monospace', fontSize:'14px',
                  fontWeight:600, color }}>
                  {value >= 0 ? '+' : '-'}{fmt(Math.abs(value))}
                </span>
              </div>
            ))}
          </Card>

          {/* Top recurring items */}
          <Card>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:12 }}>
              <div style={{ fontSize:'11px', fontWeight:600, letterSpacing:'0.06em',
                textTransform:'uppercase', color:'var(--text-secondary)' }}>Recurring Items</div>
              <span style={{ fontSize:'11px', color:'var(--text-disabled)' }}>
                {RECURRING.length} detected
              </span>
            </div>
            <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
              {RECURRING
                .map(r => ({ ...r, monthly: r.cadence === 'biweekly' ? r.amount * 26 / 12 : r.amount }))
                .sort((a, b) => b.monthly - a.monthly)
                .slice(0, 7)
                .map(r => (
                <div key={r.id} style={{ display:'flex', alignItems:'center', gap:10,
                  padding:'8px 0', borderBottom:'1px solid var(--border-default)' }}>
                  <div style={{ width:8, height:8, borderRadius:'50%',
                    background: r.type === 'income' ? 'var(--status-success)' : 'var(--status-error)',
                    flexShrink:0 }} />
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontSize:'13px', fontWeight:500, color:'var(--text-primary)',
                      whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>
                      {r.name}
                    </div>
                    <div style={{ fontSize:'11px', color:'var(--text-secondary)' }}>
                      {r.category} · {r.cadence}
                    </div>
                  </div>
                  <div style={{ textAlign:'right' }}>
                    <div style={{ fontFamily:'JetBrains Mono,monospace', fontSize:'13px', fontWeight:600,
                      color: r.type === 'income' ? 'var(--status-success)' : 'var(--text-primary)' }}>
                      {r.type === 'income' ? '+' : '-'}{fmt(r.amount)}
                    </div>
                    <div style={{ fontSize:'10px', color:'var(--text-disabled)' }}>
                      ≈ {fmt(r.monthly)}/mo
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Upcoming events timeline */}
        <Card padding="none">
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between',
            padding:'14px 18px', borderBottom:'1px solid var(--border-default)' }}>
            <div style={{ fontSize:'11px', fontWeight:600, letterSpacing:'0.06em',
              textTransform:'uppercase', color:'var(--text-secondary)' }}>
              Upcoming Events ({visibleEvents.length})
            </div>
            <div style={{ display:'flex', gap:4 }}>
              {[['all','All'],['income','Income'],['expense','Expense']].map(([id,label]) => (
                <button key={id} onClick={() => setFilterType(id)}
                  style={{ padding:'4px 10px', borderRadius:6, fontSize:'11px', fontWeight:500,
                    border:'1.5px solid', cursor:'pointer', fontFamily:'inherit', transition:'all 120ms',
                    borderColor: filterType===id ? 'var(--accent-default)' : 'var(--border-default)',
                    background:  filterType===id ? 'var(--accent-subtle)'  : 'transparent',
                    color:       filterType===id ? 'var(--accent-default)' : 'var(--text-secondary)' }}>
                  {label}
                </button>
              ))}
            </div>
          </div>
          <div>
            {visibleEvents.slice(0, 12).map((e, i, arr) => {
              const daysOut = Math.round((e.date - new Date(2026, 3, 27)) / 86400000);
              const point = series.find(s =>
                s.date.getFullYear() === e.date.getFullYear() &&
                s.date.getMonth() === e.date.getMonth() &&
                s.date.getDate() === e.date.getDate()
              );
              const balanceAfter = point?.balance ?? 0;
              const isRisky = balanceAfter < lowBalanceThreshold;
              return (
                <div key={i} style={{ display:'flex', alignItems:'center', gap:14,
                  padding:'14px 18px',
                  borderBottom: i < arr.length - 1 ? '1px solid var(--border-default)' : undefined }}>
                  <div style={{ width:48, textAlign:'center', flexShrink:0 }}>
                    <div style={{ fontSize:'10px', textTransform:'uppercase', letterSpacing:'0.05em',
                      color:'var(--text-disabled)', fontWeight:600 }}>
                      {e.date.toLocaleDateString('en-US', { month:'short' })}
                    </div>
                    <div style={{ fontSize:'18px', fontWeight:700, color:'var(--text-primary)',
                      fontFamily:'JetBrains Mono,monospace', lineHeight:1 }}>
                      {e.date.getDate()}
                    </div>
                    <div style={{ fontSize:'10px', color:'var(--text-disabled)', marginTop:2 }}>
                      in {daysOut}d
                    </div>
                  </div>
                  <div style={{ width:1, height:36, background:'var(--border-default)', flexShrink:0 }} />
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                      <span style={{ fontSize:'13px', fontWeight:500, color:'var(--text-primary)' }}>
                        {e.name}
                      </span>
                      <Badge variant={e.amount > 0 ? 'success' : 'neutral'}>
                        {e.amount > 0 ? 'income' : 'expense'}
                      </Badge>
                      {isRisky && <Badge variant="warning">low balance</Badge>}
                    </div>
                    <div style={{ fontSize:'11px', color:'var(--text-secondary)', marginTop:2 }}>
                      {e.category} · confidence: {e.confidence}
                    </div>
                  </div>
                  <div style={{ textAlign:'right', flexShrink:0 }}>
                    <div style={{ fontFamily:'JetBrains Mono,monospace', fontSize:'14px', fontWeight:600,
                      color: e.amount > 0 ? 'var(--status-success)' : 'var(--text-primary)' }}>
                      {e.amount > 0 ? '+' : '-'}{fmt(Math.abs(e.amount))}
                    </div>
                    <div style={{ fontSize:'10px', color:'var(--text-disabled)',
                      fontFamily:'JetBrains Mono,monospace' }}>
                      bal {fmt(balanceAfter)}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          {visibleEvents.length > 12 && (
            <div style={{ padding:'12px 18px', borderTop:'1px solid var(--border-default)',
              fontSize:'12px', color:'var(--text-disabled)', textAlign:'center' }}>
              + {visibleEvents.length - 12} more events in this window
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Net Worth Page
// ─────────────────────────────────────────────────────────────────────────────
function NetWorthPage({ accounts }) {
  const [loading, setLoading] = useState(true);
  const [range, setRange] = useState('1Y'); // 3M | 6M | 1Y | ALL
  const [hover, setHover] = useState(null);
  useEffect(() => { const t=setTimeout(()=>setLoading(false),700); return ()=>clearTimeout(t); }, []);

  // Combine assets history + liabilities history into a single series
  const fullHistory = useMemo(() => NET_WORTH_HISTORY.map((row, i) => {
    const liab = NET_WORTH_LIABILITIES[i] || { creditCards:0, loans:0 };
    const liabilitiesTotal = liab.creditCards + liab.loans; // negative
    return {
      ...row,
      creditCards: liab.creditCards,
      loans: liab.loans,
      liabilities: liabilitiesTotal,
      netWorth: row.total + liabilitiesTotal,
    };
  }), []);

  const sliced = range === '3M' ? fullHistory.slice(-3)
              : range === '6M' ? fullHistory.slice(-6)
              : range === '1Y' ? fullHistory.slice(-12)
              : fullHistory;

  // Current snapshot
  const totalAssets = accounts.reduce((s, a) => s + a.balanceUsd, 0);
  const totalLiabilities = LIABILITIES.reduce((s, l) => s + l.balance, 0); // negative
  const netWorth = totalAssets + totalLiabilities;

  const totalBanking   = accounts.filter(a=>a.category==='banking').reduce((s,a)=>s+a.balanceUsd,0);
  const totalBrokerage = accounts.filter(a=>a.category==='brokerage').reduce((s,a)=>s+a.balanceUsd,0);
  const totalCrypto    = accounts.filter(a=>a.category==='crypto').reduce((s,a)=>s+a.balanceUsd,0);
  const totalCC        = LIABILITIES.filter(l=>l.category==='credit').reduce((s,l)=>s+l.balance,0);
  const totalLoans     = LIABILITIES.filter(l=>l.category==='loan').reduce((s,l)=>s+l.balance,0);

  const startNW = sliced[0]?.netWorth ?? 0;
  const endNW   = sliced[sliced.length-1]?.netWorth ?? 0;
  const change  = endNW - startNW;
  const changePct = startNW > 0 ? ((change/startNW)*100).toFixed(1) : '0.0';
  const periodLabel = { '3M':'3 months', '6M':'6 months', '1Y':'12 months', 'ALL':'13 months' }[range];

  // Chart geometry — diverging axis (assets up, liabilities down)
  const W = 880, H = 280, PL = 64, PR = 20, PT = 22, PB = 36;
  const iW = W - PL - PR, iH = H - PT - PB;
  const maxAssets = Math.max(...sliced.map(d => d.total)) * 1.06;
  const minLiab   = Math.min(...sliced.map(d => d.liabilities)) * 1.06; // negative
  const yRange    = maxAssets - minLiab;
  const xStep = sliced.length > 1 ? iW / (sliced.length - 1) : iW;
  const yScale = v => PT + iH - ((v - minLiab) / yRange) * iH;
  const zeroY = yScale(0);

  // Stack assets above zero, liabilities below
  const stackUp = (key, prevKey) => {
    const pts = sliced.map((d, i) => {
      const base = prevKey ? d[prevKey] : 0;
      return { x: PL + i*xStep, yTop: yScale(base + d[key]), yBot: yScale(base) };
    });
    const top = pts.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.x},${p.yTop}`).join(' ');
    const bot = [...pts].reverse().map(p => `L${p.x},${p.yBot}`).join(' ');
    return `${top} ${bot} Z`;
  };
  const stackDown = (key, prevKey) => {
    const pts = sliced.map((d, i) => {
      const base = prevKey ? d[prevKey] : 0;
      return { x: PL + i*xStep, yTop: yScale(base), yBot: yScale(base + d[key]) };
    });
    const top = pts.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.x},${p.yTop}`).join(' ');
    const bot = [...pts].reverse().map(p => `L${p.x},${p.yBot}`).join(' ');
    return `${top} ${bot} Z`;
  };
  const netLine = sliced.map((d, i) =>
    `${i === 0 ? 'M' : 'L'}${PL + i*xStep},${yScale(d.netWorth)}`
  ).join(' ');

  const ASSET_LAYERS = [
    { key:'banking',   prev:null,        color:'#4f46e5', label:'Banking' },
    { key:'brokerage', prev:'banking',   color:'#10b981', label:'Brokerage' },
    { key:'crypto',    prev:'brokerage', color:'#f59e0b', label:'Crypto' },
  ];
  const LIAB_LAYERS = [
    { key:'creditCards', prev:null,           color:'#ef4444', label:'Credit Cards' },
    { key:'loans',       prev:'creditCards',  color:'#9333ea', label:'Loans' },
  ];

  const tickStride = Math.max(1, Math.ceil(sliced.length / 8));

  return (
    <div style={{ padding:24 }}>
      <div style={{ maxWidth:1200, margin:'0 auto', display:'flex', flexDirection:'column', gap:20 }}>

        {/* Header */}
        <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap:16 }}>
          <div>
            <h1 style={{ fontSize:'22px', fontWeight:700, color:'var(--text-primary)' }}>Net Worth</h1>
            <p style={{ fontSize:'13px', color:'var(--text-secondary)', marginTop:4, maxWidth:560, lineHeight:1.5 }}>
              Total assets minus total liabilities — your true financial position over time.
            </p>
          </div>
          <Button variant="secondary" size="sm" icon="Download">Export Report</Button>
        </div>

        {/* Hero KPI strip */}
        <div style={{ display:'grid', gridTemplateColumns:'1.4fr 1fr 1fr', gap:16 }}>
          {/* Net worth hero */}
          <Card style={{ padding:'18px 22px' }}>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
              <span style={{ fontSize:'11px', fontWeight:600, letterSpacing:'0.06em',
                textTransform:'uppercase', color:'var(--text-secondary)' }}>Net Worth</span>
              <Icon name="Scale" size="sm" style={{ color:'var(--text-secondary)' }} />
            </div>
            {loading ? (
              <><Skeleton height={36} width="60%" style={{marginTop:10}} /><Skeleton height={14} width="40%" style={{marginTop:8}} /></>
            ) : (
              <>
                <div style={{ fontFamily:'JetBrains Mono,monospace', fontSize:'30px', fontWeight:700,
                  color:'var(--text-primary)', letterSpacing:'-0.02em', marginTop:8 }}>
                  {fmt(netWorth)}
                </div>
                <div style={{ display:'flex', alignItems:'center', gap:6, marginTop:6,
                  color: change >= 0 ? 'var(--status-success)' : 'var(--status-error)' }}>
                  <Icon name={change >= 0 ? 'TrendingUp' : 'TrendingDown'} size="xs" />
                  <span style={{ fontSize:'12px', fontWeight:500 }}>
                    {change >= 0 ? '+' : ''}{fmt(change)} ({change >= 0 ? '+' : ''}{changePct}%) over {periodLabel}
                  </span>
                </div>
              </>
            )}
          </Card>

          <StatCard label="Total Assets" value={loading?'—':fmt(totalAssets)}
            icon="ArrowUpRight" loading={loading} />
          <StatCard label="Total Liabilities" value={loading?'—':fmt(Math.abs(totalLiabilities))}
            icon="ArrowDownRight" loading={loading} />
        </div>

        {/* Main chart */}
        {loading ? <Skeleton height={340} radius={8} /> : (
        <Card style={{ padding:0 }}>
          <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between',
            padding:'18px 22px 0', flexWrap:'wrap', gap:12 }}>
            <div>
              <span style={{ fontSize:'11px', fontWeight:600, letterSpacing:'0.06em',
                textTransform:'uppercase', color:'var(--text-secondary)' }}>Net Worth Composition</span>
              <div style={{ marginTop:4, fontSize:'13px', color:'var(--text-secondary)' }}>
                Assets stack above zero, liabilities below. Black line is net worth.
              </div>
            </div>
            <div style={{ display:'flex', gap:4 }}>
              {['3M','6M','1Y','ALL'].map(r => (
                <button key={r} onClick={() => setRange(r)}
                  style={{ padding:'5px 12px', borderRadius:6, fontSize:'12px', fontWeight:500,
                    border:'1.5px solid', cursor:'pointer', fontFamily:'inherit', transition:'all 120ms',
                    borderColor: range===r ? 'var(--accent-default)' : 'var(--border-default)',
                    background:  range===r ? 'var(--accent-subtle)'  : 'transparent',
                    color:       range===r ? 'var(--accent-default)' : 'var(--text-secondary)' }}>
                  {r}
                </button>
              ))}
            </div>
          </div>

          {/* Legend */}
          <div style={{ display:'flex', gap:16, padding:'10px 22px 0', flexWrap:'wrap' }}>
            {[...ASSET_LAYERS, ...LIAB_LAYERS].map(l => (
              <div key={l.key} style={{ display:'flex', alignItems:'center', gap:6 }}>
                <div style={{ width:10, height:10, borderRadius:2, background:l.color }} />
                <span style={{ fontSize:'11px', color:'var(--text-secondary)' }}>{l.label}</span>
              </div>
            ))}
            <div style={{ display:'flex', alignItems:'center', gap:6 }}>
              <div style={{ width:18, height:2, background:'var(--text-primary)', borderRadius:1 }} />
              <span style={{ fontSize:'11px', color:'var(--text-secondary)' }}>Net Worth</span>
            </div>
          </div>

          <svg viewBox={`0 0 ${W} ${H}`} style={{ width:'100%', display:'block', marginTop:6 }}
            onMouseLeave={() => setHover(null)}>
            {/* Y grid */}
            {[0, 0.25, 0.5, 0.75, 1].map(f => {
              const val = minLiab + yRange * f;
              const y = yScale(val);
              return (
                <g key={f}>
                  <line x1={PL} y1={y} x2={W-PR} y2={y}
                    stroke="var(--border-default)" strokeWidth="0.5" strokeDasharray="3 3" />
                  <text x={PL-8} y={y+4} textAnchor="end" fill="var(--text-disabled)" fontSize="9">
                    {val < 0 ? '-' : ''}${Math.abs(Math.round(val/1000))}k
                  </text>
                </g>
              );
            })}

            {/* Zero line */}
            <line x1={PL} y1={zeroY} x2={W-PR} y2={zeroY}
              stroke="var(--text-secondary)" strokeWidth="1" opacity="0.45" />

            {/* Asset stacks */}
            {ASSET_LAYERS.map(l => (
              <path key={l.key} d={stackUp(l.key, l.prev)}
                fill={l.color} fillOpacity="0.22" />
            ))}
            {/* Liability stacks (going down from 0) */}
            {LIAB_LAYERS.map(l => (
              <path key={l.key} d={stackDown(l.key, l.prev)}
                fill={l.color} fillOpacity="0.22" />
            ))}

            {/* Net-worth line */}
            <path d={netLine} fill="none" stroke="var(--text-primary)" strokeWidth="2.25"
              strokeLinejoin="round" />

            {/* X labels */}
            {sliced.map((d, i) => i % tickStride !== 0 && i !== sliced.length-1 ? null : (
              <text key={i} x={PL + i*xStep} y={H-8} textAnchor="middle"
                fill="var(--text-disabled)" fontSize="9">{d.month}</text>
            ))}

            {/* Hover targets */}
            {sliced.map((_, i) => (
              <rect key={i} x={PL + i*xStep - xStep/2} y={PT}
                width={xStep} height={iH} fill="transparent"
                onMouseEnter={() => setHover(i)} style={{ cursor:'crosshair' }} />
            ))}

            {/* Hover tooltip */}
            {hover != null && (() => {
              const d = sliced[hover];
              const x = PL + hover*xStep, y = yScale(d.netWorth);
              const tw = 200, th = 132;
              const tx = x > W - tw - 20 ? x - tw - 12 : x + 12;
              return (
                <g>
                  <line x1={x} y1={PT} x2={x} y2={PT+iH}
                    stroke="var(--border-default)" strokeWidth="1" strokeDasharray="3 3" />
                  <circle cx={x} cy={y} r="5" fill="var(--text-primary)"
                    stroke="var(--surface-card)" strokeWidth="2" />
                  <rect x={tx} y={PT} width={tw} height={th} rx="6"
                    fill="var(--surface-card)" stroke="var(--border-default)" strokeWidth="1" />
                  <text x={tx+10} y={PT+15} fill="var(--text-secondary)"
                    fontSize="10" fontWeight="600">{d.month}</text>
                  {[
                    ['Banking',     d.banking,     '#4f46e5'],
                    ['Brokerage',   d.brokerage,   '#10b981'],
                    ['Crypto',      d.crypto,      '#f59e0b'],
                    ['Credit Cards',d.creditCards, '#ef4444'],
                    ['Loans',       d.loans,       '#9333ea'],
                  ].map(([label, val, color], li) => (
                    <g key={label}>
                      <rect x={tx+10} y={PT+24+li*15+3} width={8} height={8} rx="2" fill={color} />
                      <text x={tx+22} y={PT+24+li*15+11} fill="var(--text-secondary)" fontSize="10">{label}</text>
                      <text x={tx+tw-10} y={PT+24+li*15+11} textAnchor="end"
                        fill="var(--text-primary)" fontSize="10" fontWeight="600"
                        fontFamily="JetBrains Mono,monospace">
                        {val < 0 ? '-' : ''}${Math.abs(Math.round(val/1000))}k
                      </text>
                    </g>
                  ))}
                  <line x1={tx+10} y1={PT+th-22} x2={tx+tw-10} y2={PT+th-22}
                    stroke="var(--border-default)" strokeWidth="0.5" />
                  <text x={tx+10} y={PT+th-8} fill="var(--text-primary)"
                    fontSize="11" fontWeight="700">Net</text>
                  <text x={tx+tw-10} y={PT+th-8} textAnchor="end" fill="var(--text-primary)"
                    fontSize="11" fontWeight="700" fontFamily="JetBrains Mono,monospace">
                    {fmt(d.netWorth)}
                  </text>
                </g>
              );
            })()}
          </svg>
        </Card>
        )}

        {/* Two-column: composition + monthly change */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:16 }}>
          {/* Asset / Liability composition bars */}
          <Card>
            <div style={{ fontSize:'11px', fontWeight:600, letterSpacing:'0.06em',
              textTransform:'uppercase', color:'var(--text-secondary)', marginBottom:14 }}>
              Composition Today
            </div>

            {/* Assets bar */}
            <CompositionBar
              title="Assets" total={totalAssets}
              segments={[
                { label:'Banking',   value:totalBanking,   color:'#4f46e5' },
                { label:'Brokerage', value:totalBrokerage, color:'#10b981' },
                { label:'Crypto',    value:totalCrypto,    color:'#f59e0b' },
              ].filter(s => s.value > 0)}
              valueColor="var(--text-primary)"
            />

            {/* Liabilities bar */}
            <div style={{ marginTop:18 }}>
              <CompositionBar
                title="Liabilities" total={Math.abs(totalLiabilities)}
                segments={[
                  { label:'Credit Cards', value:Math.abs(totalCC),    color:'#ef4444' },
                  { label:'Loans',        value:Math.abs(totalLoans), color:'#9333ea' },
                ].filter(s => s.value > 0)}
                valueColor="var(--status-error)"
                negative
              />
            </div>

            {/* Net summary */}
            <div style={{ marginTop:20, padding:'14px 16px', background:'var(--surface-bg)',
              borderRadius:8, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
              <span style={{ fontSize:'13px', fontWeight:600, color:'var(--text-primary)' }}>Net Worth</span>
              <span style={{ fontFamily:'JetBrains Mono,monospace', fontSize:'18px', fontWeight:700,
                color: netWorth >= 0 ? 'var(--text-primary)' : 'var(--status-error)' }}>
                {fmt(netWorth)}
              </span>
            </div>
          </Card>

          {/* Monthly change waterfall */}
          <Card style={{ padding:0 }}>
            <div style={{ padding:'16px 18px 0', fontSize:'11px', fontWeight:600,
              letterSpacing:'0.06em', textTransform:'uppercase', color:'var(--text-secondary)' }}>
              Monthly Change (last 6 months)
            </div>
            <MonthlyChangeChart history={fullHistory.slice(-6)} />
          </Card>
        </div>

        {/* Liabilities detail table */}
        <Card padding="none">
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between',
            padding:'14px 18px', borderBottom:'1px solid var(--border-default)' }}>
            <div style={{ fontSize:'11px', fontWeight:600, letterSpacing:'0.06em',
              textTransform:'uppercase', color:'var(--text-secondary)' }}>
              Liabilities ({LIABILITIES.length})
            </div>
            <Button variant="secondary" size="sm" icon="Plus">Add Liability</Button>
          </div>
          <table style={{ width:'100%', borderCollapse:'collapse', fontSize:'13px' }}>
            <thead>
              <tr style={{ borderBottom:'1px solid var(--border-default)' }}>
                {['Institution','Type','APR','Min Payment','Due Date','Balance','Utilization'].map((h,i) => (
                  <th key={h} style={{ padding:'10px 16px', fontSize:'11px', fontWeight:600,
                    letterSpacing:'0.06em', textTransform:'uppercase', color:'var(--text-secondary)',
                    textAlign: i >= 2 ? 'right' : 'left', whiteSpace:'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {LIABILITIES.map((l, ri) => {
                const utilization = l.limit ? (Math.abs(l.balance) / l.limit) * 100 : null;
                const utilColor = utilization == null ? 'var(--text-disabled)'
                  : utilization > 70 ? 'var(--status-error)'
                  : utilization > 30 ? 'var(--status-warning)'
                  : 'var(--status-success)';
                return (
                  <tr key={l.id} style={{ borderBottom: ri < LIABILITIES.length-1 ? '1px solid var(--border-default)' : undefined }}>
                    <td style={{ padding:'14px 16px' }}>
                      <div style={{ display:'flex', alignItems:'center', gap:12 }}>
                        <InstitutionAvatar name={l.institution} size={32} />
                        <div>
                          <div style={{ fontWeight:500, color:'var(--text-primary)' }}>{l.institution}</div>
                          <div style={{ fontSize:'11px', color:'var(--text-secondary)' }}>•••• {l.last4}</div>
                        </div>
                      </div>
                    </td>
                    <td style={{ padding:'14px 16px', color:'var(--text-secondary)' }}>{l.type}</td>
                    <td style={{ padding:'14px 16px', textAlign:'right',
                      fontFamily:'JetBrains Mono,monospace', color:'var(--text-secondary)' }}>
                      {l.apr != null ? `${l.apr.toFixed(2)}%` : '—'}
                    </td>
                    <td style={{ padding:'14px 16px', textAlign:'right',
                      fontFamily:'JetBrains Mono,monospace', color:'var(--text-primary)' }}>
                      {fmt(l.minPayment)}
                    </td>
                    <td style={{ padding:'14px 16px', textAlign:'right', color:'var(--text-secondary)' }}>
                      {fmtDate(l.dueDate)}
                    </td>
                    <td style={{ padding:'14px 16px', textAlign:'right',
                      fontFamily:'JetBrains Mono,monospace', fontWeight:600, color:'var(--status-error)' }}>
                      {fmt(l.balance)}
                    </td>
                    <td style={{ padding:'14px 16px', textAlign:'right' }}>
                      {utilization != null ? (
                        <div style={{ display:'flex', alignItems:'center', gap:8, justifyContent:'flex-end' }}>
                          <div style={{ width:60, height:5, borderRadius:3,
                            background:'var(--surface-raised)', overflow:'hidden' }}>
                            <div style={{ height:'100%', width:`${Math.min(100, utilization)}%`,
                              background:utilColor, borderRadius:3 }} />
                          </div>
                          <span style={{ fontFamily:'JetBrains Mono,monospace', fontSize:'12px',
                            color:utilColor, minWidth:38, textAlign:'right' }}>
                            {utilization.toFixed(0)}%
                          </span>
                        </div>
                      ) : (
                        <span style={{ fontSize:'11px', color:'var(--text-disabled)' }}>n/a</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Card>
      </div>
    </div>
  );
}

// ── Composition bar (asset/liability) ─────────────────────────────────────────
function CompositionBar({ title, total, segments, valueColor, negative }) {
  return (
    <div>
      <div style={{ display:'flex', alignItems:'baseline', justifyContent:'space-between', marginBottom:8 }}>
        <span style={{ fontSize:'12px', fontWeight:600, color:'var(--text-primary)' }}>{title}</span>
        <span style={{ fontFamily:'JetBrains Mono,monospace', fontSize:'14px', fontWeight:700, color:valueColor }}>
          {negative ? '-' : ''}{fmt(total)}
        </span>
      </div>
      <div style={{ display:'flex', height:12, borderRadius:4, overflow:'hidden',
        background:'var(--surface-raised)', marginBottom:10 }}>
        {segments.map((s, i) => (
          <div key={i} title={`${s.label}: ${fmt(s.value)}`}
            style={{ width:`${(s.value/total)*100}%`, background:s.color }} />
        ))}
      </div>
      <div style={{ display:'flex', flexDirection:'column', gap:5 }}>
        {segments.map(s => (
          <div key={s.label} style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
            <div style={{ display:'flex', alignItems:'center', gap:8 }}>
              <div style={{ width:8, height:8, borderRadius:2, background:s.color }} />
              <span style={{ fontSize:'12px', color:'var(--text-secondary)' }}>{s.label}</span>
            </div>
            <div style={{ display:'flex', gap:10, alignItems:'baseline' }}>
              <span style={{ fontSize:'11px', color:'var(--text-disabled)',
                fontFamily:'JetBrains Mono,monospace' }}>
                {((s.value/total)*100).toFixed(1)}%
              </span>
              <span style={{ fontSize:'12px', fontWeight:600, color:'var(--text-primary)',
                fontFamily:'JetBrains Mono,monospace', minWidth:80, textAlign:'right' }}>
                {negative ? '-' : ''}{fmt(s.value)}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Monthly Change waterfall (mini bar chart) ─────────────────────────────────
function MonthlyChangeChart({ history }) {
  const W = 420, H = 180, PL = 44, PR = 12, PT = 16, PB = 28;
  const iW = W - PL - PR, iH = H - PT - PB;
  const changes = history.slice(1).map((row, i) => ({
    month: row.month,
    delta: row.netWorth - history[i].netWorth,
  }));
  if (changes.length === 0) return null;

  const maxAbs = Math.max(...changes.map(c => Math.abs(c.delta))) * 1.1 || 1;
  const yScale = v => PT + iH/2 - (v / maxAbs) * (iH / 2);
  const zeroY = yScale(0);
  const barWidth = (iW / changes.length) * 0.6;
  const groupWidth = iW / changes.length;

  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{ width:'100%', display:'block', marginTop:6 }}>
      {/* zero baseline */}
      <line x1={PL} y1={zeroY} x2={W-PR} y2={zeroY}
        stroke="var(--text-secondary)" strokeWidth="1" opacity="0.4" />
      {/* axis labels */}
      <text x={PL-8} y={PT+8} textAnchor="end" fill="var(--text-disabled)" fontSize="9">
        +${Math.round(maxAbs/1000)}k
      </text>
      <text x={PL-8} y={PT+iH-2} textAnchor="end" fill="var(--text-disabled)" fontSize="9">
        -${Math.round(maxAbs/1000)}k
      </text>
      {/* Bars */}
      {changes.map((c, i) => {
        const cx = PL + i * groupWidth + groupWidth / 2;
        const positive = c.delta >= 0;
        const top = positive ? yScale(c.delta) : zeroY;
        const height = Math.abs(yScale(c.delta) - zeroY);
        const color = positive ? '#10b981' : '#ef4444';
        return (
          <g key={i}>
            <rect x={cx - barWidth/2} y={top} width={barWidth} height={height}
              fill={color} fillOpacity="0.85" rx="2" />
            <text x={cx} y={positive ? top - 5 : top + height + 11}
              textAnchor="middle" fill={color} fontSize="9" fontWeight="600"
              fontFamily="JetBrains Mono,monospace">
              {positive ? '+' : '-'}${Math.abs(Math.round(c.delta/1000))}k
            </text>
            <text x={cx} y={H - 8} textAnchor="middle"
              fill="var(--text-disabled)" fontSize="9">{c.month}</text>
          </g>
        );
      })}
    </svg>
  );
}

Object.assign(window, { CashflowForecastPage, NetWorthPage });
